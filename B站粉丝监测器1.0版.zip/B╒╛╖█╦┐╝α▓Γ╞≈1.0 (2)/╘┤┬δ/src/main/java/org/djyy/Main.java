package org.djyy;

import com.sun.javafx.binding.StringFormatter;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.Scanner;

public class Main extends Application {

    public static String posTo(String uid) throws IOException {
        String resStr="";
        BufferedReader br=null;
        StringBuilder res=new StringBuilder();
        URL url=new URL("http://8.141.83.100:8667/fss");
        HttpURLConnection connection=(HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setDoInput(true);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type","application/json;charset=utf-8");
        connection.connect();

        String reqBody="{\n" +
                "    \"akey\":\"BHUNJIMKO\",\n" +
                "    \"uid\":\""+uid+"\"\n" +
                "}";
        BufferedWriter writer=new BufferedWriter(new OutputStreamWriter(connection.getOutputStream(),"UTF-8"));
        writer.write(reqBody);
        writer.close();
        int respCode= connection.getResponseCode();
        if(respCode==HttpURLConnection.HTTP_OK)
        {
            BufferedReader in=new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while((line=in.readLine())!=null)
            {
                resStr=resStr+line;
            }
        }
        System.out.println(resStr);
        return resStr;
    }


    @Override
    public void start(Stage primaryStage) throws Exception {
        String upName="Minecraft相思故";
        String uid="346273252";
        String upSign="“即使我偶尔笨拙，努力着还不算成功。但人不就擅长,与众里找不同。再等一等我…”——《白话文》\n\n";
        File fp1=new File("info.txt");
        if(fp1.exists()) {
            Scanner in = new Scanner(fp1);
            upName = in.next();
            upSign = in.next();
            uid = in.next();
        }
        else
        {
            PrintWriter pw=new PrintWriter(fp1,"UTF-8");
            pw.println(upName);
            pw.println(upSign);
            pw.println(uid);
            pw.close();
        }

        primaryStage.setTitle("B站粉丝监测器");
        Pane mainPane = new Pane();
        Pane back=new VBox();
        Pane info=new HBox();
        Pane fssP = new HBox();
        Pane nameSign=new VBox();
        Image head=new Image("file:head2.png");
        info.setPadding(new Insets(15,15,15,15));
        fssP.setPadding(new Insets(15,15,15,15));
        ImageView hd=new ImageView(head);

        hd.setFitHeight(110);
        hd.setFitWidth(110);
        Label up=new Label("      UP主："+upName);
        Label sign=new Label("      \n"+upSign);
        sign.setWrapText(true);
        sign.setPadding(new Insets(0,0,0,26));
        sign.setMaxWidth(300);
        sign.setMinWidth(300);
        nameSign.getChildren().addAll(up,sign);
        up.setFont(Font.font(20));
        up.setStyle("-fx-text-fill:blue");
        info.getChildren().addAll(hd,nameSign);
        Scene scene = new Scene(mainPane, 450, 260);

        try{
        String jsonRes=posTo(uid);
        System.out.println("Json:"+jsonRes);
        String[] postRes = jsonRes.split("\",\"");
        System.out.println(postRes.length);
        String s= postRes[0].replace("{\"fss\":\"","");
        System.out.println(postRes[0]);
        System.out.println(postRes[1]);
        System.out.println(postRes[2]);
        System.out.println(postRes[3]);

        Label fss = new Label("    当前粉丝数：");
        fss.setFont(Font.font(17));
        Label fssn = new Label(" "+s);
        fssn.setFont(Font.font(17));
        fssn.setStyle("-fx-text-fill:purple");
        //String[] chang = getFssChange(Integer.parseInt(s));
        Label fss2 = new Label("               "+postRes[1].replace("chan\":\"",""));
        fss2.setFont(Font.font(17));
        fss2.setStyle(postRes[2].replace("css\":\"",""));
        System.out.println(postRes[1].replace("chan\":\"",""));
        fssP.getChildren().addAll(fss,fssn,fss2);
        fssP.setPadding(new Insets(1,15,25,15));
        Calendar calendar= Calendar.getInstance();
        Label lastD=new Label("               "+postRes[3].replace("LastDate\":\"",""));

        back.getChildren().addAll(info,new Label("  "),fssP,lastD);
        mainPane.getChildren().add(back);

        primaryStage.setScene(scene);
        primaryStage.show();

        }
        catch (Exception e)
        {
            back.getChildren().addAll(info,fssP,new Label("           连接服务器失败"));
            mainPane.getChildren().add(back);

            primaryStage.setScene(scene);
            primaryStage.show();
        }
    }

    public static void main(String[] args) throws IOException {

        System.out.println("Hello world!");
        launch();
    }
}